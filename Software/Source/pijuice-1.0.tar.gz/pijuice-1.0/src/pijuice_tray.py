#!/usr/bin/env python
# -*- coding: utf-8 -*-

from glob import glob
import gtk
import gobject
import os
import os.path
from string import rstrip
import sys
from pijuice import *
import time
from pijuice_gui import *

REFRESH_INTERVAL = 5000
ICON_DIR = '/usr/share/pijuice/data/images' 

class PiJuiceStatusTray:
		
    def __init__(self):
		self.tray = gtk.StatusIcon()
		self.tray.connect('activate', self.refresh)

		# Create menu
		menu = gtk.Menu()
		
		i = gtk.MenuItem("Configure")
		i.show()
		i.connect("activate", self.ConfigurePiJuice)
		menu.append(i)
		
		i = gtk.MenuItem("About...")
		i.show()
		i.connect("activate", self.show_about)
		menu.append(i)
		
		self.tray.connect('popup-menu', self.show_menu, menu)
		
		self.pijuice = PiJuice(1,0x14)

		# Initalise and start battery display
		self.refresh(None)
		self.tray.set_visible(True)
		
		gobject.timeout_add(REFRESH_INTERVAL, self.refresh, False)

    def show_menu(self, widget, event_button, event_time, menu):
        menu.popup(None, None,
            gtk.status_icon_position_menu,
            event_button,
            event_time,
            self.tray
        )

    def show_about(self, widget):
        dialog = gtk.MessageDialog(
            None,
            gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
            gtk.MESSAGE_INFO,
            gtk.BUTTONS_OK,
            """
PiJuice battery 
level status
""")
        dialog.run()
        dialog.destroy()

    def ConfigurePiJuice(self, widget):
		PiJuiceConfigGui().mainloop()
        #self.pijuiceConfig = 
		
    def refresh(self, widget):
		try:	
			charge = self.pijuice.status.GetChargeLevel()	

			if charge['error'] == 'NO_ERROR':
				b_level = charge['data']
				print b_level, '%'
			else:
				print charge
					
			b_file = ICON_DIR + '/battery_near_full.png'#"." + str(b_level / 10) + ".png"
			
			status = self.pijuice.status.GetStatus()
			#print status
			if status['error'] == 'NO_ERROR':
				self.status = status['data']
						
				if self.status['battery'] == 'NOT_PRESENT':
					if self.status['powerInput'] != 'NOT_PRESENT':
						b_file = ICON_DIR + '/no-bat-in-0.png'
					else: 
						b_file = ICON_DIR + '/no-bat-rpi-0.png'
						
				elif self.status['battery'] == 'CHARGING_FROM_IN' or self.status['powerInput'] != 'NOT_PRESENT':
					b_file = ICON_DIR + '/bat-in-' + str((b_level/10)*10) + '.png'
				elif self.status['battery'] == 'CHARGING_FROM_5V_IO' or self.status['powerInput5vIo'] != 'NOT_PRESENT':
					b_file = ICON_DIR + '/bat-rpi-' + str((b_level/10)*10) + '.png'
				else:
					b_file = ICON_DIR + '/bat-' + str((b_level/10)*10) + '.png'
			else:
				b_file = ICON_DIR + '/connection-error.png'
				self.tray.set_blinking(b_level < 5)
			
			self.tray.set_tooltip("%d%%" % (b_level))
			if os.path.exists(b_file):
				self.tray.set_from_file(b_file)
			else:
				print 'icon file not exist'
			
		except:
			print 'charge proccess error'
		return True

###############################################################################
if __name__ == '__main__':
	app = PiJuiceStatusTray()
	gtk.main()