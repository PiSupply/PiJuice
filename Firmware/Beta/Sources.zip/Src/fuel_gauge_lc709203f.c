/*
 * fuel_gauge_lc709203f.c
 *
 *  Created on: 06.12.2016.
 *      Author: milan
 */

#include "fuel_gauge_lc709203f.h"
#include "stm32f0xx_hal.h"
#include "crc8_atm.h"
#include "time_count.h"
#include "analog.h"
#include "charger_bq2416x.h"
#include "power_source.h"
#include "execution.h"

#define FUEL_GAUGE_METHOD_DV	1

extern I2C_HandleTypeDef hi2c2;
extern uint8_t resetStatus;
extern uint32_t executionState;

uint16_t batteryVoltage = 0xFFFF;
uint16_t batteryRsoc __attribute__((section("no_init")));
//volatile uint16_t emptyIndicator = 0;
uint16_t fuelGaugeTemp = 0;
int8_t batteryTemp = 25;
int16_t batteryCurrent = 0;

int8_t fuelGaugeStatus = 0;

static uint32_t fuelGaugeTaskTimer;

volatile int32_t dischargeRate = 0;
uint32_t dischargeCount;
static uint32_t dischargeCountTemp;

static uint16_t prevRsoc;

uint8_t fuelGaugeI2cErrorCounter = 0;

static uint16_t fgIcId = 0xFFFF;
volatile uint8_t fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_THERMISTOR;

const int16_t ocvSocTableNormLipo[256]={4269,3804,3447,3141,2877,2641,2435,2247,2075,1923,1788,1669,1573,1497,1441,1395,1359,1331,1306,1285,1265,1248,1233,1219,1205,1193,1181,1169,1155,1138,1121,1101,1078,1056,1033,1012,993,973,954,937,919,901,884,867,851,833,818,802,788,773,758,747,734,721,711,699,687,676,665,654,642,632,622,609,600,589,578,568,557,547,536,526,517,507,499,489,481,472,462,454,446,438,430,420,412,404,396,388,378,370,362,354,345,338,328,320,310,302,293,284,277,268,260,250,241,232,223,213,204,195,185,175,163,155,144,135,123,113,103,92,82,69,59,47,36,23,12,0,-11,-25,-37,-49,-63,-76,-89,-103,-118,-132,-147,-161,-177,-192,-207,-224,-239,-256,-273,-291,-308,-327,-344,-363,-382,-401,-420,-441,-460,-481,-501,-523,-543,-565,-589,-610,-632,-656,-678,-702,-724,-748,-771,-796,-819,-842,-865,-889,-912,-936,-960,-984,-1008,-1031,-1056,-1079,-1102,-1127,-1150,-1175,-1199,-1224,-1247,-1273,-1297,-1323,-1347,-1371,-1396,-1421,-1446,-1471,-1499,-1525,-1551,-1577,-1604,-1632,-1658,-1685,-1712,-1740,-1768,-1796,-1824,-1851,-1880,-1909,-1938,-1967,-1995,-2024,-2053,-2082,-2112,-2142,-2173,-2203,-2234,-2264,-2296,-2327,-2358,-2388,-2420,-2452,-2484,-2515,-2548,-2580,-2614,-2646,-2679,-2712,-2747,-2780,-2814,-2850,-2884,-2920,-2956,-2993,-3031,-3069,-3110,-3154,-3200,-3256};
const int16_t ocvSocTableNormLifepo4[256]={28097,26548,25030,23690,22426,21239,20117,19105,18094,17174,16307,15467,14648,13910,13247,12597,11996,11441,10945,10475,10040,9663,9293,8975,8686,8399,8155,7934,7715,7522,7342,7178,7007,6856,6700,6554,6403,6253,6109,5967,5814,5677,5539,5413,5285,5172,5054,4949,4832,4730,4629,4528,4428,4330,4227,4137,4045,3947,3859,3774,3695,3618,3532,3448,3371,3297,3221,3152,3076,3007,2946,2880,2803,2741,2676,2608,2535,2475,2401,2326,2259,2192,2124,2045,1977,1910,1829,1763,1690,1624,1554,1485,1417,1358,1293,1228,1171,1114,1058,992,941,881,829,774,728,684,634,585,544,502,461,418,389,353,322,286,255,229,197,172,145,122,101,76,51,33,12,0,-19,-39,-64,-78,-97,-107,-127,-145,-158,-171,-191,-209,-224,-233,-248,-259,-272,-290,-306,-323,-334,-352,-353,-373,-384,-401,-410,-426,-448,-461,-477,-494,-503,-521,-541,-552,-573,-586,-609,-628,-643,-668,-688,-710,-731,-753,-775,-798,-827,-850,-882,-913,-942,-979,-1006,-1042,-1080,-1113,-1149,-1185,-1225,-1264,-1303,-1339,-1379,-1424,-1471,-1517,-1546,-1593,-1628,-1665,-1703,-1745,-1788,-1823,-1861,-1887,-1926,-1958,-1989,-2023,-2060,-2089,-2115,-2140,-2169,-2192,-2220,-2237,-2261,-2284,-2311,-2334,-2343,-2368,-2396,-2410,-2428,-2447,-2464,-2481,-2497,-2519,-2536,-2556,-2578,-2595,-2616,-2635,-2662,-2684,-2705,-2753,-2765,-2795,-2836,-2870,-2908,-2961,-3014,-3082,-3165,-3277,-3432,-3694,-4197,-5466};
uint16_t ocvSocTbl[256] __attribute__((section("no_init")));
uint16_t rSocTbl[256] __attribute__((section("no_init")));
uint16_t c0 __attribute__((section("no_init")));
int32_t soc __attribute__((section("no_init")));

int8_t FuelGaugeReadWord(uint8_t cmd, uint16_t *word) {
	uint8_t readData[10] = {0x16, cmd, 0x17, 0, 0, 0};

	HAL_I2C_Mem_Read(&hi2c2, 0x16, cmd, 1, readData+3, 3, 1);
	/*HAL_Delay(2);
	HAL_I2C_Mem_Read_IT(&hi2c2, 0x16, cmd, 1, readData+3, 3);
	uint32_t timeout = HAL_GetTick() + 2;
	while (HAL_I2C_GetState(&hi2c2) != HAL_I2C_STATE_READY && timeout > HAL_GetTick());
	HAL_Delay(2);*/
	if (Crc8Block(0, readData, 5) == readData[5]) {
		*word = (((uint16_t)readData[4])<<8) | readData[3];
		fuelGaugeI2cErrorCounter = 0;
		return 0;
	} else {
		fuelGaugeI2cErrorCounter ++;
		return -1;
	}
}

void FuelGaugeWriteWord(uint8_t cmd, uint16_t word) {
	uint8_t writeData[5] = {0x16, cmd, word, word>>8, 0};
	writeData[4] = Crc8Block(0, writeData, 4);
	//HAL_Delay(2);
	HAL_I2C_Mem_Write(&hi2c2, 0x16, cmd, 1, (uint8_t*)&writeData[2], 3, 1);
	//uint32_t timeout = HAL_GetTick() + 2;
	//while (HAL_I2C_GetState(&hi2c2) != HAL_I2C_STATE_READY && timeout > HAL_GetTick());
	//HAL_Delay(2);
}

uint16_t GetSocFromOCV(uint16_t ocv){
	int i;
	for (i = 0; i < 256; i++) {
		if (ocvSocTbl[i]>=ocv) return i;
	}
	return 255;
}

void FuelGaugeDvInit(void) {
	int16_t i;
	uint16_t ocv50 = 3800, ocv10 = 3649, ocv90 = 4077;
	//uint16_t r10=1.1*91, r50=1.1*83, r90=1.1*76; // lifepo
	uint16_t r50=1.82*156, r10=1.82*160, r90=1.82*155; // BP7X
	//int16_t dOCV10 = ocv50-ocv10, dOCV90 = ocv90-ocv50;
	int32_t ocvRef50 = 3791, ocvRef10 = 3652, ocvRef90 = 4070;
	const int16_t *ocvSocTableRef = ocvSocTableNormLipo;
	c0 = 1820;

	if ( currentBatProfile != NULL ) {
		if (currentBatProfile->chemistry==BAT_CHEMISTRY_LIFEPO4) {
			ocvSocTableRef = ocvSocTableNormLifepo4;
			ocvRef50 = 3243;
			ocvRef10 = 3111;
			ocvRef90 = 3283;
		} else {
			ocvSocTableRef = ocvSocTableNormLipo;
			ocvRef50 = 3791;
			ocvRef10 = 3652;
			ocvRef90 = 4070;
		}

		c0 = currentBatProfile->capacity;
		if (currentBatProfile->ocv50 != 0xFFFF) {
			ocv50 = currentBatProfile->ocv50;
		} else {
			ocv50 = ((uint16_t)currentBatProfile->regulationVoltage+175+currentBatProfile->cutoffVoltage)*10;
		}
		if (currentBatProfile->ocv10 != 0xFFFF) ocv10 = currentBatProfile->ocv10; else ocv10 = 0.96322*ocv50;
		if (currentBatProfile->ocv90 != 0xFFFF) ocv90 = currentBatProfile->ocv90; else ocv90 = 1.0735*ocv50;

		if (currentBatProfile->r50 != 0xFFFF) r50 = (int32_t)c0*currentBatProfile->r50/100000;
		if (currentBatProfile->r10 != 0xFFFF) r10 = (int32_t)c0*currentBatProfile->r10/100000; else r10 = r50;
		if (currentBatProfile->r90 != 0xFFFF) r90 = (int32_t)c0*currentBatProfile->r90/100000; else r90 = r50;
	}

	int32_t k1 = ((ocvRef90-ocvRef50)*(230-26)*(ocv50-ocv10))>>10;
	for (i = 0; i < 26; i++) {
		ocvSocTbl[i] = ocv50 - ((k1*ocvSocTableRef[i])>>16); //ocv50 - (((((int32_t)(4070-3791)*(230-26.0)*dOCV10)>>8)*ocvSocTableNorm[i])>>10);
		rSocTbl[i] = 65535/(r50+(r50-r10)*(i-128.0)/(128-26));
	}

	int32_t OCVdSoc50 = (((int32_t)ocv50)<<13) / (230-26);
	k1 = ((ocvRef90-ocvRef50)*(ocv50-ocv10))>>4;
	int32_t k2 = (((ocvRef50-ocvRef10)*(ocv90-ocv50))>>4);
	for (i = 26; i < 128; i++) {
		int32_t d1= (OCVdSoc50 - ((k1*ocvSocTableRef[i])>>9))*(230.0-i); //ocv50/(230-26.0) - (((((int32_t)(4070-3791)*dOCV10))*ocvSocTableNorm[i])>>18);
		int32_t d2= (OCVdSoc50 - ((k2*ocvSocTableRef[i])>>9))*(i-26); //ocv50/(230-26.0) + (((((int32_t)(3652-3791)*dOCV90))*ocvSocTableNorm[i])>>18);
		ocvSocTbl[i] = (d2+d1)>>13;
		rSocTbl[i] = 65535/(r50+(r50-r10)*(i-128.0)/(128-26));
	}

	k2 = ((ocvRef50-ocvRef10)*(230-26)*(ocv90-ocv50))>>10;
	for (i = 128; i < 256; i++) {
		ocvSocTbl[i] = ocv50 - ((k2*ocvSocTableRef[i])>>16); //ocv50 + (((((int32_t)(3652-3791)*(230-26.0)*dOCV90)>>8)*ocvSocTableNorm[i])>>10);
		rSocTbl[i] = 65535/(r50+(r50-r90)*(i-128.0)/(128-230));
	}
}

void FuelGaugeInit(void) {
	volatile int8_t succ;
	MS_TIME_COUNTER_INIT(fuelGaugeTaskTimer);

	//HAL_Delay(5);
	/*HAL_I2C_Mem_Read(&hi2c2, 0x16, 0x11, 1, (uint8_t*)&fgIcId, 2, 10);
	//int8_t succ = FuelGaugeReadWord(0x11, &fgIcId);
	volatile HAL_I2C_StateTypeDef i2c2Status = HAL_I2C_GetState(&hi2c2);
	if ( i2c2Status == HAL_I2C_STATE_TIMEOUT || fgIcId == 0xFFFF) {
		fuelGaugeStatus = 1;
		return;
	}*/

	if (FuelGaugeReadWord(0x11, &fgIcId) != 0) {
		fuelGaugeStatus = 1;
		return;
	}

	// Set operational mode
	FuelGaugeWriteWord(0x15, 0x0001); //3.7V

	// set APA
	FuelGaugeWriteWord(0x0b, 0x36); //FuelGaugeWriteWord(0x0b, 0x2d);//

	// set change of the parameter
	FuelGaugeWriteWord(0x12, 0x0001);

	// set APT
	FuelGaugeWriteWord(0x0C, 0x3000);//FuelGaugeWriteWord(0x0C, 0x001E);//

	if ( currentBatProfile != NULL && currentBatProfile->ntcB != 0xFFFF && currentBatProfile->ntcResistance == 1000 ) {
		// Set NTC B constant
		FuelGaugeWriteWord(0x06, currentBatProfile->ntcB);
	}

	// Set NTC mode
	FuelGaugeWriteWord(0x16, 0x0001);
	FuelGaugeWriteWord(0x16, 0x0001);
	fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_THERMISTOR;

	FuelGaugeReadWord(0x09, &batteryVoltage);
	FuelGaugeReadWord(0x0F, &batteryRsoc);
	prevRsoc = batteryRsoc;
	dischargeCount = HAL_GetTick();
	dischargeCountTemp = dischargeCount;

	if (tempSensorConfig == BAT_TEMP_SENSE_CONFIG_AUTO_DETECT || tempSensorConfig == BAT_TEMP_SENSE_CONFIG_NTC)
	{
		succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);
		if (succ!=0) succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);

		// check if NTC connected
		if (fuelGaugeTemp <= 0x09E4 || succ!=0 || currentBatProfile==NULL || currentBatProfile->ntcB == 0xFFFF || currentBatProfile->ntcResistance != 1000) {
			// not NTC connected should give reading below -20C
			fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_I2C;
			// Set I2C mode
			FuelGaugeWriteWord(0x16, 0x0000);
			batteryTemp = mcuTemperature;
		} else {
			fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_THERMISTOR;
			// Set NTC mode
			FuelGaugeWriteWord(0x16, 0x0001);
			batteryTemp = ((int16_t)fuelGaugeTemp - 2732) / 10;
		}
	} else {
		fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_I2C;
		// Set I2C mode
		FuelGaugeWriteWord(0x16, 0x0000);
		batteryTemp = mcuTemperature;
	}
	//volatile uint16_t NTCset = 0xFFFF; // read NTC sensor config
	//succ = FuelGaugeReadWord(0x16, &NTCset);

#if FUEL_GAUGE_METHOD_DV
	if (!resetStatus) {
		FuelGaugeDvInit();
	}
	//if ( !POW_5V_BOOST_EN_STATUS() && !POW_VSYS_OUTPUT_EN_STATUS()) {
	if (!(executionState==EXECUTION_STATE_NORMAL || executionState==EXECUTION_STATE_UPDATE || executionState==EXECUTION_STATE_CONFIG_RESET)) {
		//DelayUs(500000);
		soc = GetSocFromOCV(GetSampleVoltage(POW_VBAT_SENS_CHN)*(int32_t)1374/1000)*8388906;
		batteryRsoc = (soc>>7)*125>>21;
	}
#endif
}

void FuelGaugeTask(void) {
	volatile int8_t succ;
	static uint8_t ntcDetectCnt;
	static uint8_t updateCnt;
	/*if (fuelGaugeStatus) {
		batteryTemp = mcuTemperature;
		return;// if not present
	}*/

	int32_t dt = MS_TIME_COUNT(fuelGaugeTaskTimer);
	if ( dt > 125 ) {

		// set APA
		//FuelGaugeWriteWord(0x0b, 0x2d);

#if FUEL_GAUGE_METHOD_DV
		batteryVoltage = GetAverageBatteryVoltage(POW_VBAT_SENS_CHN);

		MS_TIME_COUNTER_INIT(fuelGaugeTaskTimer);
		// Dynamic voltage state of charge evaluation
		int32_t ind = soc>>23;
		int32_t dif= (int32_t)ocvSocTbl[ind]-batteryVoltage;
		batteryCurrent = (dif*(((uint32_t)c0*rSocTbl[ind])>>6))>>10;
	    int32_t dSoC = (((int32_t)dif*dt*(((int32_t)596*rSocTbl[ind])>>8)))>>8;//dif*596*dt/res;
		soc = soc - dSoC;
		soc = soc<=2139095040?soc:2139095040;
		soc = (soc>=0)?soc:0;
		batteryRsoc = (soc>>7)*125>>21;

		if (CHARGER_IS_BATTERY_PRESENT() && batteryVoltage > 2550) {
#else
		volatile uint16_t batVol = GetSampleVoltage(POW_VBAT_SENS_CHN);

		if (CHARGER_IS_BATTERY_PRESENT() && batVol > (2550 * 1000 / 1374)) {

			MS_TIME_COUNTER_INIT(fuelGaugeTaskTimer);
			// read battery voltage
			succ = FuelGaugeReadWord(0x09, &batteryVoltage);

			/*volatile uint16_t changeOfTheParameter = 0xFFFF;
			succ = FuelGaugeReadWord(0x12, &changeOfTheParameter);

			volatile uint16_t apa = 0xFFFF;
			succ = FuelGaugeReadWord(0x0b, &apa);*/

			// read state of charge
			succ = FuelGaugeReadWord(0x0F, &batteryRsoc);

			if (batteryRsoc != prevRsoc && (HAL_GetTick() - dischargeCount) > 500) {
				dischargeRate = ((int32_t)prevRsoc - batteryRsoc) * (int32_t)1843200 / (int32_t)(HAL_GetTick() - dischargeCount);
				batteryCurrent = (dischargeRate * (currentBatProfile!=NULL ? currentBatProfile->capacity : 10000)) >> 10;
				dischargeCount = HAL_GetTick();
				dischargeCountTemp = HAL_GetTick();
				prevRsoc = batteryRsoc;
			} else if ((HAL_GetTick() - dischargeCount) > 1843200) {
				dischargeRate = 0;
				dischargeCount = HAL_GetTick();
				dischargeCountTemp = HAL_GetTick();
			} else if ( (HAL_GetTick() - dischargeCountTemp) > 50000) {
				//batteryCurrent = (int32_t)(dischargeRate>0?1800:-1800) * (currentBatProfile!=NULL ? currentBatProfile->capacity : 10000) / (int32_t)(HAL_GetTick() - dischargeCount);
				//dischargeRate = ((int32_t)prevRsoc - batteryRsoc) * (int32_t)1843200 / (int32_t)(HAL_GetTick() - dischargeCount);
				int16_t newCurr;
				if (dischargeRate!=0) newCurr = (((int32_t)(dischargeRate>0?1:-1)) * (int32_t)1843200 / (int32_t)(HAL_GetTick() - dischargeCount) * (currentBatProfile!=NULL ? currentBatProfile->capacity : 10000)) >> 10;
				else newCurr = 0;
				//if ( (newCurr>0?newCurr:-newCurr) < (batteryCurrent>0?batteryCurrent:-batteryCurrent) ) batteryCurrent = newCurr;
				/*if (batteryCurrent > 120) {
					batteryCurrent -= 120;
				} else if (batteryCurrent < -120) {
					batteryCurrent += 120;
				}*/
				//batteryCurrent -= (batteryCurrent >> 2);
				dischargeCountTemp = HAL_GetTick();
			}
#endif

			if (fuelGaugeTempMode == FUEL_GAUGE_TEMP_MODE_THERMISTOR) {
				// read battery temperature
				succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);
				if (succ!=0) succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp); // try once more
				//HAL_I2C_Mem_Read(&hi2c2, 0x16, 0x08, 1, (uint8_t*)&fuelGaugeTemp, 2, 10);
				if (succ==0) {
					// check if NTC connected
					if (fuelGaugeTemp <= 0x09E4 || currentBatProfile==NULL || currentBatProfile->ntcB == 0xFFFF || currentBatProfile->ntcResistance != 1000) {
						if (tempSensorConfig == BAT_TEMP_SENSE_CONFIG_AUTO_DETECT || tempSensorConfig == BAT_TEMP_SENSE_CONFIG_ON_BOARD)
						{
							// not NTC connected should give reading below -20C
							fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_I2C;
							// Set I2C mode
							FuelGaugeWriteWord(0x16, 0x0000);
							batteryTemp = mcuTemperature;
						} else {
							batteryTemp = -127; // this will disable charging with NTC Config
						}
					} else {
						batteryTemp = ((int16_t)fuelGaugeTemp - 2732) / 10;
						if (ntcDetectCnt++ > 30) {
							// Set NTC mode
							FuelGaugeWriteWord(0x16, 0x0001);
							ntcDetectCnt = 0;
						}
					}
				} else {
					batteryTemp = mcuTemperature; // use board temperature as backup
				}
			} else {
				// try to detect sensor connection in
				if ( ntcDetectCnt++ > 25 && (tempSensorConfig == BAT_TEMP_SENSE_CONFIG_AUTO_DETECT || tempSensorConfig == BAT_TEMP_SENSE_CONFIG_NTC)) {
					FuelGaugeWriteWord(0x16, 0x0001);
					succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);
					if (fuelGaugeTemp <= 0x09E4 || currentBatProfile==NULL || currentBatProfile->ntcB == 0xFFFF || currentBatProfile->ntcResistance != 1000) {
						// not NTC connected should give reading below -20C
						// Set I2C mode
						FuelGaugeWriteWord(0x16, 0x0000);
						batteryTemp = mcuTemperature;
					} else {
						fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_THERMISTOR;
					}
					ntcDetectCnt = 0;
				} else {
					fuelGaugeTemp = mcuTemperature * 10 + 2732;
					fuelGaugeTemp = fuelGaugeTemp > 0x0D04 ? 0x0D04 : fuelGaugeTemp;
					fuelGaugeTemp = fuelGaugeTemp < 0x09E4 ? 0x09E4 : fuelGaugeTemp;
					FuelGaugeWriteWord(0x08, fuelGaugeTemp);
					batteryTemp = mcuTemperature;
					//succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);
				}
			}

			updateCnt ++;
			if (updateCnt == 5) FuelGaugeWriteWord(0x12, 0x0001); // set change of the parameter
			if (updateCnt == 80) FuelGaugeWriteWord(0x0b, 0x36); // set APA
			if (updateCnt == 190) FuelGaugeWriteWord(0x0C, 0x3000); // set APT
		} else {
#if !FUEL_GAUGE_METHOD_DV
			batteryRsoc = 0;
			batteryVoltage = batVol * 1374 / 1000;
#endif
			batteryTemp = mcuTemperature;
		}

	}

}

void FuelGaugeSetBatProfile(const BatteryProfile_T *batProfile) {
	int8_t succ;
	if (fuelGaugeStatus) return;// if not present

	if ( batProfile != NULL && batProfile->ntcB != 0xFFFF && batProfile->ntcResistance == 1000 ) {
		// Set NTC B constant
		FuelGaugeWriteWord(0x06, batProfile->ntcB);
	}

	// Set NTC mode
	FuelGaugeWriteWord(0x16, 0x0001);
	FuelGaugeWriteWord(0x16, 0x0001);
	fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_THERMISTOR;

#if FUEL_GAUGE_METHOD_DV
	FuelGaugeDvInit();
#endif
	/*succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);
	if (succ!=0) succ = FuelGaugeReadWord(0x08, &fuelGaugeTemp);

	// check if NTC connected
	if (fuelGaugeTemp <= 0x09E4 || succ!=0 || batProfile==NULL || batProfile->ntcB == 0xFFFF || batProfile->ntcResistance != 1000) {
		// not NTC connected should give reading below 20C
		fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_I2C;
		// Set I2C mode
		FuelGaugeWriteWord(0x16, 0x0000);
		batteryTemp = mcuTemperature;
	} else {
		fuelGaugeTempMode = FUEL_GAUGE_TEMP_MODE_THERMISTOR;
		// Set NTC mode
		FuelGaugeWriteWord(0x16, 0x0001);
	}*/
}

